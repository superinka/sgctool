<?php
Class Report_Model extends MY_Model{
	var $table = 'tb_daily_report';
	var $key = 'id';
	
}