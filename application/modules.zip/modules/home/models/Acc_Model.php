<?php
Class Acc_Model extends MY_Model{
	var $table = 'tb_user';
	var $key = 'id';
}