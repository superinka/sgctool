<?php
Class Department_Model extends MY_Model{
	var $table = 'tb_department';
	var $key = 'id';
}