<?php
Class Role_Model extends MY_Model{
	var $table = 'tb_role';
	var $key = 'id';
}