<?php
Class Home_Model extends MY_Model{
	var $table = 'tb_employee';
	var $key = 'id';
}