<?php
Class Project_Model extends MY_Model{
	var $table = 'tb_project';
	var $key = 'id';
}