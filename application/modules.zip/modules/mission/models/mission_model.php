<?php
Class Mission_Model extends MY_Model{
	var $table = 'tb_task';
	var $key = 'id';
}